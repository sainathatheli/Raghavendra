#include <iostream>
using namespace std;

class Ex{

public:
     void methodOne(); //function declaration

};

void Ex::methodOne(){
  cout<<"we are in methodOne"<<endl;
}

int main(){
    Ex eobj1;
    eobj1.methodOne();
    return 0;
}