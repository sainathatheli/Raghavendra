#include <iostream>
using namespace std;

//creating a class

class Room{

    //data members
public:       //access modifier
    double length;
    double width;
    double height;
 
    double calculateArea(){  //member function
        return length*width;
    }
 
    double calculationVolume(){
        return length*width*height;
    }

};

int main(){

  //creating an object
    Room room1,room2; //room1 is an object of a class Room
   //Room room2;
   //initialize the variables or assigning a value to data members
   room1.length=20;
   room1.width=30.8;
   room1.height=19.2;

   //Calculate and display the area and volume of the room
   //calling memeber functions;
   double area=room1.calculateArea();
   double volume=room1.calculationVolume();

   cout<<"Area of a room is : "<<area<<endl;
   cout<<"Volume of a room is : "<<volume<<endl;


   //initialize the variables or assigning a value to data members
   room2.length=10;
   room2.width=30;
   room2.height=12.2;

   //Calculate and display the area and volume of the room
   //calling memeber functions;
   double area1=room2.calculateArea();
   double volume1=room2.calculationVolume();

   cout<<"Area of a room is : "<<area1<<endl;
   cout<<"Volume of a room is : "<<volume1<<endl;
    
    return 0;


}