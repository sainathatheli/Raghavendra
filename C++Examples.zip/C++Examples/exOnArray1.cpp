#include <iostream>

using namespace std;

int main(){

//delcaring and initializing an array
         // 0  1  2  3  4
int arr[5]={30,50,20,40,20};

double arr2[4]; //declaring an array
//accessing the array elements  by using index;
 int res=arr[1];

 cout<<"Array element at index position 1 is : "<<res<<endl;

  //initializing an array 
 arr2[0]=10;
 arr2[1]=30;
 arr2[2]=40.0;
 arr2[3]=39;

cout<<"Array  arr2 element at index position  2 is : "<<arr2[2]<<endl;
 
//accessing the elements with the help for loop;
cout<<"Display the elements using forloop :"<<endl;
 for(int i=0;i<5;i++){
    
    cout<<arr[i]<<" ";

 }

  return 0;

}