#include <iostream>
using namespace std;

class Wall{

private:    //access modifiers is private we can with in the class
    double length;
    double height;

public:
    Wall(){ //Default constructor
       length=20;
       height=12.4;
       cout << " constructors are called automatically when object created "<<endl;
       cout<<"area of wall is : "<<length*height<<endl;
      }

};

int main(){

     Wall wall1; //calling a constructor.
    return 0;
}