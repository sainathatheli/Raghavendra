#include <iostream>

using namespace std;

int main(){
 
int a;
int b;
int c;


cout<<"if else if statement  comparing three variables  "<<endl;

cout<<"enter the value for a "<<endl;
cin>>a;

cout<<"enter the value for b "<<endl;
cin>>b;

cout<<"enter the value for c "<<endl;
cin>>c;


if( a>b && a>c){

	cout<<"a is greater than b ,c ";

}else if(b>a && b>c){

   cout<<"b is greater than a ,c ";

}else{

  cout<<"c is greater than a ,b ";

}

return 0;

}