#include <iostream>

using namespace std;

int main(){

int arr[2][2];

//initialize the array using for loop

for(int i=0;i<2;i++){
    for(int j=0;j<2;j++){
        cout<<"enter the element at index position ["<<i<<"]["<<j<<"]"<<endl;
        cin>>arr[i][j];
    }
    
}
cout<<"displaying the elements from two dimensional array : "<<endl;

for(int i=0;i<2;i++){
    for(int j=0;j<2;j++){
        cout<<arr[i][j]<<" ";
       
    }
    cout<<"\n";
}

}