#include <iostream>
using namespace std;
//function overriding
class MyClassA{ //base class

public:
    void display(){
        cout<<"Display method from Base class"<<endl;
    }
};

class MyClassB : public MyClassA{
    public:
     void display(){//overriding function from parent to child
      cout<<"Display method from dervied class"<<endl;
     }
};

int main(){
   MyClassB bobj,bobj1;
   MyClassA* ptr;//pointer of base class
   bobj.display(); //it will called from child class or dervied class
  
   //1. accessing overriden method from Baseclass using :: operator
  // bobj1.MyClassA::display(); //display method of base called.

   //2.using pointer we can call overriden method from base class.
   ptr=&bobj;
   cout<<"From Base class "<<endl;
   //call the display from the base class
   ptr->display();
   

}



