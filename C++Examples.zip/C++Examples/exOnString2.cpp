#include <iostream>
using namespace std;

int main(){
    cout<<"example on string"<<endl;
  string str;
 /*cout<<"enter the string :"<<endl;
  cin>>str;//single word

  cout<<"the text is : "<<endl;
  cout<<str;
*/

//getline(inputstream,location of the varaible to store);
cout<<"enter the line of string :"<<endl;
getline(cin,str);

cout<<"the line of text enterd by the user : "<<endl;
cout<<str;


  return 0;


}
