#include <iostream>

using namespace std;

int main(){

  int i=1 ;

cout<<"While with break statement"<<endl;

  while(i<=10){
    
     cout<<i<<endl;
     if(i==5){
      break;
     }
    
     i++;
     
  }


}