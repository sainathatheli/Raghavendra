#include <iostream>
#include <cstring>
using namespace std;

int main(){
 
  char str1[10]="Hello";
  char str2[10]="world";
  char str3[10];
  int len;

  //copy str1 int str3;
  strcpy(str3,str1);//here str1 is copied into str3;
  cout<<"after copied into str3 is : "<<str3<<endl;

  //concatenates str1 and str2
  strcat(str1,str2);// it add the text at the end of string str1 
  cout<<"after the concatenation of str1 and str2 : "<<str1<<endl;

  //total length of str1 after concatenation.
     
      len=strlen(str1);
    cout<<"length of string str1 is : "<<len<<endl;


    len=strlen(str2);
    cout<<"length of string str2 is : "<<len;
return 0;

}