#include <iostream>
using namespace std;

class Complex{
   private:
   int real;
   int img;

   public:
     Complex(){  //default constructor
        real=0;
        img=0;
     }
     
     Complex(int r,int im){  //paramterized constructor.
        real=r;
        img=im;
     }

    //opertaor overlaod function on binary (+)

    Complex operator + (Complex obj){
       Complex temp;
         /**
          * here   real,img ==> c1 object values in expression
          * obj.real,obj.img ==> c2 object values in expression
          * 
          * temp.real,temp.img ==> c3 object
         */
       temp.real=real+obj.real;
       temp.img=img+obj.img;
 
        return temp;

    }

     void display(){
        cout<<"the Complex value is :"<<endl;  //12+10i
        cout<<real<<"+"<<img<<"i"<<endl;
     }


};

int main(){
  
  Complex c1(10,20);
  Complex c2(30,23);
    
     //addition on user-defined type
  Complex c3=c1+c2; // c1.add(c2)   here in operator function
                       //c1(real,img) // Complex c1(10,20);
                       //c2 =obj  //c2(30,20);
                        //c3 will act as Complex temp

   c3.display();//it will add real values of c1 and c2 and img values of c1,c2


}