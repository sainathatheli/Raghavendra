#include <iostream>

using namespace std;

int main(){

int x;
int y;

//reading the values from the keyboard

cout<<"Enter the value for x : \n";
cin>>x;

cout<<"Enter the value for y: \n";
cin>>y;


//display the x and y values;

cout<<"x values is : "<<x<<endl;
cout<<"y values is : "<<y<<endl;
return 0;
}