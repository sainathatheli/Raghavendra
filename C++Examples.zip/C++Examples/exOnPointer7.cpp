#include <iostream>
using namespace std;

//array name will act as pointer

int main(){
 float  arr[3];

//insert the data using array name as pointer notation.
 cout<<"Enter the 3 elements: "<<endl;
 for(int i=0;i<3;i++){
    //cin>>arr[i]    //arrayname
    cin>>*(arr+i); //pointername

 }
//display the data using array name as pointer notation.
 cout<<"displaying the elements"<<endl;
 for(int i=0;i<3;i++){
    //cout<<arr[i]    //arrayname
    cout<<*(arr+i)<<endl; //pointername
    
 }


}