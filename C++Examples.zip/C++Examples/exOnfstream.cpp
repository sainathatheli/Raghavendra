#include <iostream>
#include <fstream>

using namespace std;

int main(){

   ofstream outfile;
   string data;
   //open(filename,mode);
   outfile.open("abc.txt",ios::out);
    //1st way writing data into a file
   //outfile<<"welcome to files handling in c++";

    //read the data from keyboard
  cout<<"enter the data to write into a file"<<endl;
   getline(cin,data);

   //after reading data write into file.
   outfile<<data;

   //close the file
   outfile.close();

   return 0;

}