#include <iostream>
using namespace std;

class ExUn{
    private:
     int x;
    
    public:
      ExUn(){
        x=5;
      }
     
      //operator overloading function
      //prefix
      void operator ++ (){
        ++x;
      }
     
       //operator overloading function
      //postfix
      void operator ++ (int){
        x++;
      }
     
      void display(){
         cout<<"x : "<<x<<endl;
      }
        
};
int main(){
   
   ExUn exobj, result;
   //prefix increment 
   cout<<"preprefix increment : ";
   ++exobj;

   exobj.display();

  //prefix increment 
  cout<<"postprefix increment : ";
   exobj++;
 
   exobj.display();




}