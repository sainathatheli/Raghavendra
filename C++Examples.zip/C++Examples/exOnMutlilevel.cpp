#include <iostream>
using namespace std;
//multilevel
class MyClassA{
    public:
        void methodOne(){
           cout<<"we are in methodOne of A class "<<endl;
        }
};

class MyClassB : public MyClassA{

    public:
    void methodTwo(){
        cout<<"we ar in methodTwo of B Class "<<endl;
    }
};

class MyClassC : public MyClassB{

public:
    void methodThree(){
        cout<<"we ar in methodThree of C Class "<<endl;
    }

};

int main(){

    MyClassC cobj;


   //child class from C
   cobj.methodThree(); //

   //child class from B
   cobj.methodTwo();

  cobj.methodOne();
    return 0;



}