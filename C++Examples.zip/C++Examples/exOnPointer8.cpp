#include<iostream>
using namespace std;

const int size=5;

int main(){
     
  int num[size] ={30,10,29,45,56};
  int *ptr[size];

  //assign the address of the each cell to pointer array
  for(int i=0; i<size;i++){
    ptr[i]= &num[i];
  }

  for(int i=0;i<size;i++){
    cout<<*ptr[i]<<endl;
  }

  return 0;

}
