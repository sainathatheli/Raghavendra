#include <iostream>
using namespace std;

class Animal {

   private:
      string color;
   protected:
      string type;

   public:
       void eating(){
        cout<<"can eat !"<<endl;
       }
    
      void sleep(){
        cout<<"Can sleep !"<<endl;
      }

      void setColor(string cl){
        color=cl;
      }
      string getColor(){
        return color;
      }

};

class Dog : public Animal{

     public:

        void setType(string ty){ //initialize protected type variable.
            type=ty;
        }
        string getType(){
            return type;
        }

        void barking(){
            cout<<"Dog  barking like bow..boww..."<<endl;
        }

     

};

int main(){

    Dog dobj;
    //initialize the private member.
    dobj.setColor("black"); 
     //initilaize the protected member.
     
     dobj.setType("mammals");

     cout<<"displaying the Details of animals"<<endl;
     cout<<"Animal Color  is : "<<dobj.getColor()<<endl;
     cout<<"Animal Type is :"<<dobj.getType()<<endl;

     dobj.eating();
     dobj.sleep();
     dobj.barking();

    return 0;
}









