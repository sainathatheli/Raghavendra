#include <iostream>
using namespace std;

int main(){
 //displayin the address of the variables.
 int x=5;
 int y=17;

 cout<<"the address of the x is :  "<<&x<<endl;
 cout<<"the address of the y is : "<<&y<<endl;

return 0;


}