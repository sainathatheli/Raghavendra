#include <iostream>
using namespace std;

class Wall{

private:    //access modifiers is private we can with in the class
    double length;
    double height;

public:
    Wall(double len,double hgt){ //parameterized constructors
         length=len;
         height=hgt;
    }

    double calculationArea(){ //member function
        return length*height;
    }

};

int main(){

    Wall wall(30,12.3); //creating an object with parameterized constructor 
    double area=wall.calculationArea();
    cout<<"Area of wall is : "<<area<<endl;
}