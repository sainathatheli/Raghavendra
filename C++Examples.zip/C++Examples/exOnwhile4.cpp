#include <iostream>

using namespace std;

int main(){

  int i=1 ;

cout<<"While with continue statement"<<endl;
/**
 * 
 * skip the fifth iteration 
*/
  while(i<=10){ //1 2 3 4 5 6
    
     if(i==5){//5th iteration skipped

      i++; //6
      continue;
     }
    cout<<i<<"\t";

     i++;
     
  }


}