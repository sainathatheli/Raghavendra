#include <iostream>
using namespace std;

class MyClassA{
    public:
        void methodOne(){
           cout<<"we are in methodOne of A class "<<endl;
        }
};

class MyClassB{
    public:
        void methodTwo(){
           cout<<"we are in methodTwo of B class "<<endl;
        }
};


//multiple inheritance dervied from one or more class
class MyClassC : public MyClassA,public MyClassB{
     public:
        void methodThree(){
           cout<<"we are in methodThreeof C class "<<endl;
        }

};


int main(){
  
  //creating the object for child class

  MyClassC cobj;
  cobj.methodOne();
  cobj.methodTwo();
  cobj.methodThree();
 

}