#include <iostream>
using namespace std;

class Student{

public:
   double marks1,marks2;

   void calculationAverage(){
     double avg= (marks1+marks2)/2;
     cout<<"Average is :"<<avg;
   }
};

 Student calculation(double m1,double m2){//returtyp of a fucntion is student obejct
    Student s1;  //createing an object of student in function
    s1.marks1=m1;
    s1.marks2=m2;
    return s1;
 }

int main(){
     
      Student sobj= calculation(30,50);
       sobj.calculationAverage();
    return 0;
}

