#include <iostream>
using namespace std;
//function overriding
class MyClassA{ //base class

public:
    void display(){
        cout<<"Display method from Base class";
    }
};

class MyClassB : public MyClassA{
    public:
     void display(){//overriding function from parent to child
      cout<<"Display method from dervied class";
     }
};

int main(){
   MyClassB bobj;
   bobj.display(); //it will called from child class or dervied class
  

}



