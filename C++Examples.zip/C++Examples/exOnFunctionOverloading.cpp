#include <iostream>
using namespace std;

class Ex3{

public:
    
    int addition(int x,int y){
        return x+y;
    }

    int addition(int x,int y,int z){
          return x+y+z;
    }

    void methodOne(string s){
      cout<<"Hello "+s<<endl;
    }
   
   void  methodOne(int x){
     cout<<"Int value is : "<<x<<endl;
   }

};

int main(){
   Ex3 eob3;
   
   eob3.methodOne("ravi");
   int res=eob3.addition(10,30,20);
   
   cout<<"sum of three numers: "<<res<<endl;

   eob3.methodOne(10);
   cout<<"sum of two numbers : "<<eob3.addition(10,30);


   return 0;

}