#include <iostream>
#include <vector>
using namespace std;

int main(){

    //vector;
    vector<int> v ={120,200,50,20,60};

    cout<<"size of vector: "<<v.size()<<endl;



    cout<<"Displaying the elements from Vector "<<endl;
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<" ";
    }
   
   //creating the iterator for the Vector 
   vector<int>::iterator ptr;
  cout<<"displaying first element "<<endl;
   ptr=v.begin();
  cout<<"element at v[0] : "<<*ptr<<endl;
 
  cout<<"displaying last element"<<endl;
  ptr=v.end()-1;
  cout<<"element at v[4] : "<<*ptr<<endl;










   return 0;
}