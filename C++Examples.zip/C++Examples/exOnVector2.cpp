#include <iostream>
#include <vector>
using namespace std;

int main(){
//basic initiliazer
vector<int> v1={10,40,20,50};

//uniform initiliazer;
vector<int> v2{2,8,6,3,1};

//constructor initiliazer
vector<int>  v3(12,4);
     
cout<<"elements from v1 "<<endl;
for(int i :v1){
  cout<<i<<" ";
}

cout<<"\n elements from v2 "<<endl;
for(int i :v2){
  cout<<i<<" ";
}
cout<<"\n elements from v3 "<<endl;
for(int i :v3){
  cout<<i<<" ";
}
return 0;

}