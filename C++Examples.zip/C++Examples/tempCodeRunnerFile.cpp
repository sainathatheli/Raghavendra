 public:

        void setType(string ty){ //initialize protected type variable.
            type=ty;
        }
        string getType(){
            return type;
        }

        void barking(){
            cout<<"Dog  barking like bow..boww..."<<endl;
        }

     