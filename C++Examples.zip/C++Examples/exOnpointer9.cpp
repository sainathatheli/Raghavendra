#include<iostream>
using namespace std;

const int size=3;

int main(){

  char *pftr[size]={"banaa","apple","mango"};
   
   for(int i=0;i<size;i++){
    cout<<*(pftr+i)<<endl;
   }

return 0;
}