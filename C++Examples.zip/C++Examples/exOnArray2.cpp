#include <iostream>

using namespace std;

int main() {
//                     0        1      2        3        4
 string fruits[5]={"orange","mango","grapes","banana","kiwi"};

 cout<<"Accessing the element from fruits array : "<<fruits[2]<<endl;

  //change the  array element at index 2;

fruits[2]="watermelon";
cout<<"after change Accessing the element from fruits array : "<<fruits[2]<<endl;


return 0;
}