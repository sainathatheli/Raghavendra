#include <iostream>

using namespace std;

int main(){
 
int a;
int b;

bool bl=true;

cout<<"Conditional if Statement  "<<endl;

cout<<"enter the value for a "<<endl;
cin>>a;

cout<<"enter the value for b "<<endl;
cin>>b;


if(a>b){

  cout<<"a is greater than b:  "<<a<<endl;

}

if(b>a){

  cout<<"b is greater than a "<<b<<endl;

}


if(!bl){

 cout<<"a is equal to b";
}



return 0;


}