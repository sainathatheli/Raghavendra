#include<iostream>
using namespace std;

int main(){

string fruit="banana";
string* pf=&fruit;//assigning the address to pointer variable

//  *pf=&fruit -->invalid  pf=&fruit -->valid
cout<<"before modifying the pointer variable"<<endl;
cout<<"content form the pointer variable : "<<*pf<<endl;
cout<<"content form the variable fruit is : "<<fruit<<endl<<endl;

//modify the pointer value 
*pf="kiwi";

cout<<"after  modifying the pointer variable banana to kiwi"<<endl;
cout<<"content form the pointer variable : "<<*pf<<endl;
cout<<"content form the variable fruit is : "<<fruit<<endl<<endl;


//modify the variable value
fruit="orange";
cout<<"after  modifying the varable kiwi to orange \n"<<endl;
cout<<"content form the pointer variable : "<<*pf<<endl;
cout<<"content form the variable fruit is : "<<fruit<<endl;


return 0;
}