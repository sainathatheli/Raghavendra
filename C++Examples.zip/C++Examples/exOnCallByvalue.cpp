#include <iostream>
using namespace std;

void greeting(string s){
    cout<<"Hello "+s<<endl;
}

void addition(int &x,int &y){ //function with reference parameters.
    cout<<"sum of two numbers : "<<x+y;
}

int main(){
    
   int a=10;
   int b=20;
   greeting("praveen");//call by value or pass by value

   addition(a,b); // call by reference
   
return 0;

}