#include <iostream>

using namespace std;

void sayHello(string n="dixit"){ //default parameter value.

  cout<<"welcome "+n<<endl;
}

int main(){
    
    sayHello("srikar");//welcome srikar
    sayHello() ;// welcome dixit 
    sayHello("sumit");


}