#include <iostream>
using namespace std;

class Ex2{

public:  //public access modifier
    int x;

private:  //private access modifier
    int y;

protected:
    int z; //protected access modifier.

public:
   void methodOne(){
    cout<<"we are in public methodOne";
   }

private:
     void methodTwo(){
    cout<<"we are in privae methodTwo";
   }
protected:
  void methodThree(){
    cout<<"we are in protected methodThree";
   }


};
  
 int main(){
    Ex2 eobj2;
    eobj2.x=20;
   cout<<"public variable x: "<<eobj2.x;
   cout<<"\n";

    //cout<<"private variable y: "<<eobj2.y;
   //cout<<"\n";

  //  cout<<"protected  variable z: "<<eobj2.z;
   //cout<<"\n";
   
   //calling funtion.
   eobj2.methodOne();
  // eobj2.methodTwo();
   //eobj2.methodThree();

    return 0;
 }
   





