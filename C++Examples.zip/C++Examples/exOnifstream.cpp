#include <iostream>
#include <fstream>

using namespace std;

int main(){
  
  string rdata;
  ifstream infile;
  infile.open("simple.txt",ios::in);
/*
  cout<<"Reading data from the file"<<endl;
  
  //reeading data from file and storing to variable rdata >> operator
  infile>>rdata; //here it will read only one word from file

  cout<<rdata;
*/
  cout<<"\n Reading data from the file using while loop"<<endl;
                         //all the line will read from file
   while(getline(infile,rdata)){
    cout<<rdata<<endl;
   }




  //close the file
  infile.close();


}