#include <iostream>
using namespace std;
//Return Value from Operator Function(++operator)
class ExUn{
  
  private:
   int x;

   public:
      ExUn(){
        x=5;
      }

      
      //operator Function prefix increment ++variable
      ExUn operator ++ (){
        ExUn temp;
        temp.x=++x;
        return temp;
      }

     //operator Function postfix increment variable++
      ExUn operator ++ (int){
        ExUn temp;
        temp.x=x++;
        return temp;
      }

      void display(){
        cout<<"x value is : "<<x<<endl;
      }


};

int main(){
   ExUn exobj1,result;
   
   cout<<"Prefix increment : "<<endl;
   result=++exobj1; //operator overloading function
    result.display();
   
   cout<<"Postfix increment : "<<endl;
   result=exobj1++; //operator overloading function
    result.display();


    return 0;
}