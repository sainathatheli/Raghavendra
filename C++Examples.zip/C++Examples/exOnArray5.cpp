#include <iostream>

using namespace std;

int main(){

//declaring and initializing the 2 dimensional array.

int arr[2][2] = { {1,4},{4,5}} ; //2*2=4 elements

int arr1[2][3] ={{10,39,32},{23,20,15}}; //2*3 =6 elements.

//total no of elements : rowsize * colsize 

//accessing the elements:

cout<<"accessing the element at index location [1][1]: "<<arr[1][1]<<endl; //5

cout<<"accessing the elements using forloop : "<<endl;

for(int i=0;i<2;i++){ //rowsize 
    for(int j=0;j<2;j++){
        cout<<arr[i][j]<<" ";
    }
    cout<<"\n";
}


}