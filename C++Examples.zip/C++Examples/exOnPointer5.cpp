#include <iostream>
using namespace std;

//function declaration 
void swap(int* ,int *);

int main(){
   int a=10;
   int b=20;
   
   cout<<"before swap the values of a,b "<<endl;
   cout<<"a = "<<a<<" "<<"b = "<<b<<endl;

   //calling a function 
    swap(&a,&b);
   
    cout<<"after swap the values of a,b "<<endl;
    cout<<"a = "<<a<<" "<<"b = "<<b<<endl;



  return 0;
}

//function definition
void swap(int* n1,int* n2){
    int term=*n1;
    *n1=*n2;
    *n2=term;
}