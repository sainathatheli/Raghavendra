#include<iostream>

using namespace std;

int main(){

 int i=1; //declaring and initializing a variable
 cout<<"While loop examples"<<endl;

while(i<=10){
   cout<<i<<"\n";
   i++ ; // i=i+1 or +=i  
}

}

