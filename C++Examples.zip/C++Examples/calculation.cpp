#include <iostream>

using namespace std;

int main(){

int x;

int y ;

int op;

cout <<"Enter the value for x :"<<endl;
cin>>x;

cout <<"enter the value for y :"<<endl;
cin>>y;

//addition

op=x+y;
cout<<"adddition of two numbers : "<<op<<endl;

//substraction

op=x-y;
cout<<"substraction of two numbers : "<<op<<endl;

//multiplication

op=x*y;
cout<<"multiplication of two numbers : "<<op<<endl;


//division

op=x/y;
cout<<"Division of two numbers : "<<op<<endl;


//modulus

op=x%y;
cout<<"Modulus of two numbers : "<<op<<endl;


}