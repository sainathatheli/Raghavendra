#include <iostream>

using namespace std;

int main(){

int marks[5]; //declaring an array

//initializing array with forloop by using keyboard
cout<<"Initializing an array : "<<endl;

for(int i=0;i<5;i++){
   cout<<"Insert an element at index position: "<<i<<endl;
   cin>>marks[i];

}

//displaying the array with forloop;
cout<<"displaying an elements from marks array "<<endl;
for(int i=0;i<5;i++){
   cout<<marks[i]<<" ";

}
cout<<"Displayin the elements using for-each loop"<<endl;
for(int al:marks){
   cout<<"array elements : "<<al <<endl;
}



}