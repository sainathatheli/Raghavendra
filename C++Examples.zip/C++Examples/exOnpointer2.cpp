#include <iostream>
using namespace std;

int main(){
   cout<<"assigning address to a pointer variable"<<endl;

   int x=5; 
   //declare pointer variable 
   int* pt;

   //assign the address of x into pointer variable
    pt=&x;

    //print the value of x
    cout<<"x = "<<x<<endl;

    //print the address of the x;
    cout<<"Address of x (&x) = "<<&x<<endl;

    //print the pointer pt
    cout<<"pt address is : "<<pt<<endl;

    //print the content of the address pointer pt using deference operator
    cout<<"Content of the address pointer :"<<*pt;

    return 0;
}