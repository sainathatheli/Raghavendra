#include <iostream>
using namespace std;

class Student{
    public:
       double marks1,marks2;

    public:
      Student(double m1,double m2){
           marks1=m1;
           marks2=m2;
      }
};

void calculationAverage(Student s1){ //function as Student Object parameter.
    double avg=(s1.marks1+s1.marks2)/2;
    cout<<"Average of marks is : "<<avg<<endl;
}

int main(){
  Student s(200,200);

  //calling the funtion
   calculationAverage(s);

return 0;
}