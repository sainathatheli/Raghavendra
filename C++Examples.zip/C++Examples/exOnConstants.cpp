#include <iostream>

using namespace std;

int main(){

 const int x=30; //read-only variable

 cout << "constant values is "<<x<<endl;
 
 // x=50; //reassign the const variable;

// cout << "constant values is "<<x<<endl;



}