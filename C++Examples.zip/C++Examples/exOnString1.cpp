#include <iostream>
using namespace std;

int main(){
/**
 char str[100];
 cout<<"enter a string : "<<endl;
 cin>>str;   //its will read single world
 cout<<"String from str is : "<<str<<endl;

  cout<<"enter a string : "<<endl;
 cin>>str;
 cout<<"String from str is : "<<str; //it will not read line of text.
    //because << operator works as scanf() in c and considers a space " "has a terminating
    //character.
*/
/**
 * read a line of text 
 * get(arrayName,size of arry);
 * 
*/
  
  char str1[100];
  cout<<"Enter a line of text :"<<endl;
  cin.get(str1,100);

  cout<<"the line of text is :: "<<endl;
  cout<<str1;
    
    
 return 0;

}