#include <iostream>

using namespace std;

int main(){
int x=10;
 int y=20;
 float z=23.1;
 char ch='a';
  bool bl=true;
  
   //declaring string variable 

  string name="sumit";

   //delcaring same type variables using comma  ,

  int a,b,c;

  a=b=c=20;

  char c1=65;
 
 cout<<"the Variables are :"<<endl;
 cout<<x<<endl;
 cout<<y<<endl;
 cout<<z<<endl;
 cout<<ch<<endl;
 cout<<"the boolean value is : "<<bl<<endl;
 cout <<"name is : "<<name<<endl;

 cout<<a<<endl;
 cout<<"c1 65 ascII is : "<<c1;

return 0;
}
