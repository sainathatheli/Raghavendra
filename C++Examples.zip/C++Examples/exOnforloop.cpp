#include <iostream>
 
using namespace std;

int main()
{
   //int i=1;
  cout<<"ForLoop example : "<<endl;

  for(int i;i<=10;i++){
  
     cout<<i<<endl;
  }
    return 0;
}
