#include <iostream>
using namespace std;

double calculation(double numerator,double denominator){

   double div;
  if(denominator==0){
    throw "Division cannot be done..by 0.!";
  }
  div=numerator/denominator;
  return div;
   
}
int main(){
  double res;
    try{
       res= calculation(10,0);
       cout<<"Divsion of two numbers : "<<res<<endl;
    }catch(const char* msg){
       cout<<msg<<endl;
    }
   return 0;
}

