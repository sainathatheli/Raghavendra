#include<iostream>

using namespace std;

int main(){

int i=1;
int n=5;

cout<<"multiplication of table  5 is : "<<endl;

while(i<=10){
  
  cout<<n<<"X"<<i<<"="<<n*i<<endl;
  i++;
}


}