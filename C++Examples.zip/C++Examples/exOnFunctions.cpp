#include <iostream>

using namespace std;

//user defined function with return type void and zero parameters.
void greeting(){
  cout<<"welcome to c++ functions "<<endl;
}

//create a function to perform sum of two numbers and return the sum value.
int  addition(int x,int y){
     return x+y;
}

int main(){
     cout<<"working the functions from main : "<<endl;

    //calling a function 
    greeting();
    int res=addition(30,20);
    cout<<"sum of two numbers is : "<<res;

}
