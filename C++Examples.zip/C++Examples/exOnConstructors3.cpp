#include <iostream>
using namespace std;
/**
 * copy constructor is used to copy data of one object to another(&).
*/
class Wall{

private:    //access modifiers is private we can with in the class
    double length;
    double height;

public:
    Wall(double len,double hgt){ //parameterized constructors
         length=len;
         height=hgt;
    }
    //copy constructor with a Wall object as parameter.
    //copy data of the object parameter.
    Wall(Wall &obj){
      length=obj.length;
      height=obj.height;
    }

    double calculationArea(){ //member function
        return length*height;
    }

};

int main(){

    Wall wall1(30,10); //creating an object with parameterized constructor 

//copy the conents f Wall1 to Wall2;
    
    Wall wall2=wall1; //copy constructor 

    double area=wall1.calculationArea();
    cout<<"Area of wall is : "<<area<<endl;

    //calling a function with copyconstructor .
   
    double area1=wall2.calculationArea();
    cout<<"Area of wall is with copyConstructor object : "<<area1<<endl;

}