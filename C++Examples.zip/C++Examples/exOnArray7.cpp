#include <iostream>

using namespace std;

//passing array as function arrugment.
void myMethod(int a[5]){

 cout<<"displaying the array elements from function "<<endl;
   
   for(int i=0;i<5;i++){
     cout<<a[i]<<" ";
   }

}

int main(){

   cout<<"Passing an Array as function argument "<<endl;
   int arr[5]={10,30,40,20,50};
   myMethod(arr);

}