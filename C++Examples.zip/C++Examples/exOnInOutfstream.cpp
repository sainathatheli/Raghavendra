#include <iostream>
#include <fstream>

using namespace std;

int main(){
  string rdata;
  fstream iofile;

  iofile.open("xyz.txt",ios::out);
  
  cout<<"writing data into afile using fstream"<<endl;

 iofile<<"hello welcome to handling writing data into xyz file.\n" ;
 iofile.close();



  cout<<"Reading data from a  file using fstream simple.txt"<<endl;
   iofile.open("simple.txt",ios::in);

   while(!iofile.eof()){
    char ch;
    iofile>>ch;
    cout<<ch;
   }
   iofile.close();

 return 0;
}