#include <iostream>
using namespace std;

//passing referenes with out pointers.

void swap(int &n1,int &n2){

 int term=n1;
   n1=n2;
   n2=term;

}

int main(){
   int a=10;
   int b=20;
   cout<<"before swap the values : "<<endl;
   cout<<a<<" "<<b<<endl;

   swap(a,b);

    cout<<"after swap the values : "<<endl;
   cout<<a<<" "<<b<<endl;
  return 0;
}