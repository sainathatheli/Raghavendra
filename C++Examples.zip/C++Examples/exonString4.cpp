//Example on string object manipulate.

#include <iostream>
using namespace std;

int main(){

string str1="hello"; //string object
string str2="world";
string str3;
int len;

//copy string str1 into str3;

str3=str1;
cout<<"after copy the string in str3 : "<<str3<<endl;

//concatentation str1 and str2 (+ operator);
str3=str1+str2;
cout<<"after concatentation in str3 : "<<str3<<endl;

//get the total length of the string str2 using size() or length()
len=str2.size();
cout<<"length of the string str2 is :  "<<len<<endl;

//print character from the str2 where index position is 4;
cout<<"index position of a string str2 at 4 : "<<str2[4]<<endl;

str3=str1.append(str2);
cout<<"appending a string in str3 "<<str3<<endl;


return 0;
}
