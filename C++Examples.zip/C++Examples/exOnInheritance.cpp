#include <iostream>
using namespace std;
//single inheritance
//Base class  or //Parent class// super class
class Animal{
 
 public:
    void eat(){
        cout<<"can eat!"<<endl;
    }

    void sleep(){
        cout<<"can sleep !"<<endl;
    }

};

//derived class //child class or subclass
class Dog :public Animal{

public:
    void barking(){
        cout<<"bow bow......"<<endl;
    }

};

int main(){

    Dog dogObj;//child or derived class object created.
    
    //calling parent class function.
    dogObj.eat();
    dogObj.sleep();

    //calling the child class function.
    dogObj.barking();
    
    return 0;

}
