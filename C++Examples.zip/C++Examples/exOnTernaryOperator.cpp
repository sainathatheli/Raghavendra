#include <iostream>

using namespace std;

int main(){
 
int a=5;
int b=15;
string res;


//ternary operator

res=a>b?"a is greater than b ":"b is greater than a";

cout<<res; 


return 0;


}