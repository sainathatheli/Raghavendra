#include <iostream>

using namespace std;

int main(){

int i=1;

do
{
    /* code */
   cout<<i<<endl;
   i++;   
} while (i<=10);

return 0;

}