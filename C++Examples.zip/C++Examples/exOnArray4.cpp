#include <iostream>

using namespace std;

int main(){

int arr[5]={30,40,10,30,5};  

//get the size of an array,we can use use sizeof()
cout<<"array size in bytes : "<<sizeof(arr)<<endl;

//here for int it allocates 4 bytes for each element 
//4X5=20 bytes.

//to find out how many elements an array has , you have to divide the size of the array
//  by the size of the type it contains.

 int noOfelements=sizeof(arr)/sizeof(int);

 cout<<"Array Size is : "<<noOfelements<<endl;

 cout<<"Display the elements using of loop"<<endl;

 for(int i=0;i<sizeof(arr)/sizeof(int);i++){
   cout<<arr[i]<<" ";
 }
 






}