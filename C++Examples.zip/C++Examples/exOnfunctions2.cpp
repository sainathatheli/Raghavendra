#include<iostream>

using namespace std;

void greeting() ;//function declaration 

string sayHello(string name); //function declaration

int main(){
    cout<<"declared a funtion after the main method "<<endl;
    greeting(); //calling a function

    //calling sayHello
  string res=  sayHello("ram");
  cout<<res;
}

//user defined function with return type void and zero parameters.
void greeting(){  //function defintion
  cout<<"welcome to c++ functions "<<endl;
}

//Function definiton
 string sayHello(string name){
    return "hello "+ name; 
 }


