#include <iostream>

using namespace std;

int main(){
 
int a;
int b;

cout<<"if else statement   "<<endl;

cout<<"enter the value for a "<<endl;
cin>>a;

cout<<"enter the value for b "<<endl;
cin>>b;

if(a>b){

  cout<<"a is greater than b:  "<<a<<endl;

}else{

  cout<<"b is greater than a "<<b<<endl;

}

return 0;

}