#include <iostream>
using namespace std;

int main(){

  int x=40;
  int y=3;
  int z;
  char choice;

  cout<<"caluclation \n";
  cout<<"enter the choice from below + - / * %"<<endl;
  cin>>choice;

  switch (choice)
  {
  case '+': z=x+y;
            cout<<"sum of two numbers is : "<<z<<endl;
           break;

 case '-': z=x-y;
            cout<<"substraction of two numbers is : "<<z<<endl;
           break;

 case '*': z=x*y;
            cout<<"multiplication of two numbers is : "<<z<<endl;
           break;

  case '/': z=x/y;
            cout<<"division of two numbers is : "<<z<<endl;
           break;
  case '%': z=x%y;
            cout<<"modulluos of two numbers is : "<<z<<endl;
           break;
  
  default: cout<<"invalid choice";
    break;
  }

}