
<?php
//indexed Based Array
//empty array
$arr1 = array();

//declare and initialize

$arr2 = array(10,40,50,20);

echo "number of elements in array arr1 : ";
echo count($arr2);

$arr3 = [];

$arr4 =[20,40,10,50,30];
echo "<br> number of elements in array arr4 : ";
echo count($arr4);
//accessing the elements using index 
echo "<br> Displaying the elements using index at 2:";
echo $arr4[2];

echo "<br> Displaying the elements using var_dump():";
var_dump($arr4);

echo "<br> Displaying the elements using print_r():";
print_r($arr4);

//for delete an unelement we use unset()
echo "<br>deleting the element 50 from array arr4:";
unset($arr4[3]);
echo "<br> Displaying the elements after delete using var_dump():";
var_dump($arr4);

echo "<br> Displaying the elements using for loop: <br>";

for($i=0;$i<count($arr4)-1;$i++){
     echo $arr4[$i];
     echo "\t";
}



echo "<br> Displaying the elements using foreach: <br>";

foreach($arr4 as $at){
      echo "$at \t";
}