<?php 
echo "welcome to php";

?>