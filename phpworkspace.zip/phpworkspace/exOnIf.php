

<?php

$a=20;
$b=10;
$is_v =true;
if($a > $b){
    echo "a is greater than b : $a";
    echo "<br>";
}

if($is_v){
    echo "using boolean condition <br>";
    print("if condition <br>");
}
/*
if($a=$b){
    echo "a is equal to b <br> ";
}*/
/*
if($a= 10){ here its not checking the condition it will assigning a value to variable
    echo "a is equal to b <br>";
}
*/

if(20 == $a){ 
    echo "a is equal to that value <br>";
}
 echo "last a value is $a"
?>