<?php
#MYSQLi procedural  //2nd way

$hostname='localhost';
$username='root';
$password ='root';
$dbname ='mydb';

//create connection

$conn = mysqli_connect($hostname,$username,$password,$dbname);

//check connection established to database or not

if(!$conn){

    die("connection failed: " . mysqli_connect_error());
}



//execute the update query
$sqlQuery="update employee set ename='scott',sal=8000 where empid=1004 ";

//In 2ndway we will use one function mysqli_query(connection,query)

if(mysqli_query($conn,$sqlQuery)){
   echo "Record Updated Successfully";
}else{
    echo "Error: " . $sqlQuery. "<br>" .mysqli_error($conn);
}

//close the connection
mysqli_close($conn);

?>