<?php
#MYSQLi procedural  //2nd way //multi-insert 

$hostname='localhost';
$username='root';
$password ='root';
$dbname ='mydb';

//create connection

$conn = mysqli_connect($hostname,$username,$password,$dbname);

//check connection established to database or not

if(!$conn){

    die("connection failed: " . mysqli_connect_error());
}

//execute the queries 
//here insert query . TO insert data into employee(mydb)

//we can execute multiple queries using mysqli_multi_query()
//every insert statement must be terminated with semi-colon(;)
$sqlQuery="insert into employee (empid,ename,sal) values (1004,'four',4000);";

$sqlQuery .="insert into employee (empid,ename,sal) values (1005,'mohan',7000);";

$sqlQuery .="insert into employee (empid,ename,sal) values (1006,'laxman',8000);";
//In 2ndway we will one function mysqli_query(connection,query)

if(mysqli_multi_query($conn,$sqlQuery)){
   echo "Mutliple Records inserted successfully";
}else{
    echo "Error: " . $sqlQuery. "<br>" .mysqli_error($conn);
}

//close the connection
mysqli_close($conn);

?>