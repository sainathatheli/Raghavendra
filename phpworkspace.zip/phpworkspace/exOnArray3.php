<?php

//Associative array 
$ht =[]; //delcaring empty array

$ht['title'] = 'php arrays';
$ht['description'] ='learn how to use arrays';

var_dump($ht);
print_r($ht);

//Display element using with name or key
echo "<br>";
echo $ht['title'];

echo "<br>";
echo "Displaying the elements using foreach <br>";


//foreach ($array_name as $key => $value) {
   //process element here;
//}

foreach($ht as $nm => $v1){
    echo"key is : $nm ";
    echo"value is : $v1 <br>";
}


//Declare and initilaze the Associative array

$ct =[
       'TN' => 'Chennai',
       'TS' => 'HYD',
        'MH' => 'MUM'
     ];

echo "<br>";
echo "Displaying the elements using foreach <br>";  
    
foreach($ct as $st => $cp){
    echo "The capital city of $st is $cp <br>" ;

}