
<?php
#MYSQLi(Object oriented) 1-st way

$hostname='localhost';
$username='root';
$password ='root';

//create the connection

   $conn =  new mysqli($hostname,$username,$password);

//check connection is established or not 

if( $conn-> connect_error){
  die("connection failed : " . $conn->connect_error);
}

echo "Connected successfully ";




?>