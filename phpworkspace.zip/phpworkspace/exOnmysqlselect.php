<?php
#MYSQLi procedural  //2nd way

$hostname='localhost';
$username='root';
$password ='root';
$dbname ='mydb';

//create connection

$conn = mysqli_connect($hostname,$username,$password,$dbname);

//check connection established to database or not

if(!$conn){

    die("connection failed: " . mysqli_connect_error());
}

//execute the queries 
//select query

$sqlQuery="select empid,ename,sal from employee";

//execute the select  queries
  $result  = mysqli_query($conn,$sqlQuery);

//fetch the data from the database ($result)

if(mysqli_num_rows($result) > 0){

//output data of each row
echo "EMPID   ENAME   SALARY <br>";
while ($row = mysqli_fetch_assoc($result)){
 #echo "EmpId: " . $row["empid"]. " Name : " . $row["ename"]. " SAL:" . $row["sal"]."<br>";
  echo $row["empid"] . "\t" . $row["ename"] . "\t" . $row["sal"]."<br>";
}
}else{
    echo "0 Records";
}

//close the connection
mysqli_close($conn);

?>