<?php
#MYSQLi procedural  //2nd way

$hostname='localhost';
$username='root';
$password ='root';

//create connection

$conn = mysqli_connect($hostname,$username,$password);

//check connection established to database or not

if(!$conn){

 die("connection failed: " . mysqli_connect_error());
}


echo "Conencted successfully using MYSQLi procedural";


?>