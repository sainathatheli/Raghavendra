
<html>

<?php
#Define a variable 

$balance =400;
$student_id =101;
$student_name="martin";
$student_marks=300.0;

echo "using var_dump() checking type of variable";
var_dump($student_id);
var_dump($student_marks) ;


#display the variables
echo 'balance is '. $balance;
echo "<br>";
echo "student id is $student_id";

?>

<p> 
 <?php  echo"$balance" ?>
</p>
<p> <?=$student_name?>

</html>