
<?php
//defining a function
function welcome(){
    echo "welcome to Php functions";
}

//function wwith parameters
function employee_details($ename){//parameter 
   echo '<br> welcome ' . $ename;
}
//multiple parameters separated by comma(,)
function addition($a,$b){
    echo '<br>addition is :'. $a+$b;
    echo "<br>";
}

//function with retun value
function st_concat($st1,$st2){
   return $st1 . $st2;
 }

 function add_numbers($a,$b){
     return $a+$b;
}

function mutli_numbers($a,$b=5){  //function with default arugment
    return $a * $b;
}
     
//calling a function
welcome();
employee_details('Ramu');  //actual value passing to fucntion is called arugments
addition(10,20);
$fullst = st_concat('rama','krishna');
echo $fullst;
echo "<br>";

$res =add_numbers(30,40);
echo $res;

echo "<br>";

$res1 =mutli_numbers(40);
echo $res1;


