
<?php

$a=40;
$b=50;
$c=30;

if ($a > $b && $a > $c){ 
    echo "a is greater than b,c ";
}elseif($b > $a && $b > $c){ 
    echo "b is greater than a,c";
}else{ 
    echo "c is greater than a,c ";
}


?>