
<?php

echo "Employee Details are : <br>";

echo "FirstName :" .  $_POST['fname'];
echo  "<br>";
echo "LastName  :" .  $_POST['lname'];
echo  "<br>";