
<?php

$arr1 =  [30,40,50,80,10];
echo 'size is : '. count($arr1);
var_dump($arr1);

//unset 1
unset($arr1[1]);
echo 'afterdelet size is : '. count($arr1);
var_dump($arr1);

$arr1[1]=80;
echo 'after adding an element is : '. count($arr1);
var_dump($arr1);

