
<?php

$number=1;
$i=1;
$total=0;
while($number <=10){
    echo "number is :$number <br>";
    $number++;
}


while($i<=10){
    $total=$total+$i;
    $i++;
}
echo "sum of 10 numbers : $total";

?>

<h1><?=$total ?></h1>