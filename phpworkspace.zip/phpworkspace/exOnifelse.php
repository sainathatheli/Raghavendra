

<?php

$a=30;
$b=20;

if($a > $b){
 echo "a is greater than b ";
}else {
    echo "b is greater than a";
}



?>