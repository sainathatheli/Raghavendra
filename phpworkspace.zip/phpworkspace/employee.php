<html>

<body>

<form action="data.php" method="post">

FirstName : <input type="text" name="fname"><br><br>
LastName  : <input type="text" name="lname"><br><br>

 <input type="submit" value="save">




</form>
</body>
</html>