<?php

$i=1;
$num=1;
$total=0;
for($i;$i<=10;$i++){ 
    echo "$i \t";
}

for($num;$num<=10;$num++){ 
    $total+=$num; //$total = $total+$num
}

echo "<br>sum of ten numbers is : $total";

