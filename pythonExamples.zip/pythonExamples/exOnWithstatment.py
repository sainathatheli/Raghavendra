
with open("temp.txt","w") as f:
    f.write("welcome to temp file \n")
    f.write("we working with with statement \n")
    f.write("explicilty not required to close the file object")

print(f.closed)