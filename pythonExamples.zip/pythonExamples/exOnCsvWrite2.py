import csv

with open("C:\\Users\\sainath\\Desktop\\empdata.csv","w",newline="") as f:
   wt =csv.writer(f) #writer will return csv writer object
   wt.writerow(["ENO","ENAME","ESAL","EADDR"])
   n=int(input("Enter number of employees record : "))
   for i in range(n):
      eno=input("Enter Employee No: ")
      ename=input("Enter Employee Name: ")
      esal=input("Enter  Employee Salary : ")
      eaddr=input("Enter Employee Address : ")
      wt.writerow([eno,ename,esal,eaddr])

print("Employee Record are successfully Writen into CSV file")
      


