i=1

while i<=10:
    if i==5:
        i=i+1
        continue  #fifth iteration will be stopped(skipped ) continue to 6th iteration
    print(i) #while loop
    i+=1

print("out of the while statement")
