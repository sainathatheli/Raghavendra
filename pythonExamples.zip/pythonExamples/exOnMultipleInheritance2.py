class p1:
    def m1(self):
        print("we are in m1 of P1 class")

class p2:

    def m1(self):
        print("Parent2 method of m1 ")

    def m2(self):
        print("we are in m2 method of P2 class")

class C(p2,p1):
      
    def m3(self):
        print("we are in m3 method of Child class")


cobj = C()

cobj.m1()
cobj.m3()
cobj.m2()



           