#We can define customexception class inherits from the Exceptions class
class InvalidAgeException(Exception):
    def __init__(self,st):
        self.msg=st

try:
    age=int(input("Enter the age : "))
    if age < 18 :
        raise InvalidAgeException("Age should be  greater or equal to 18 then only cast a vote")
    else:
        print("Valid Age You can Cast your vote :")

except InvalidAgeException as msg:
    print(msg)