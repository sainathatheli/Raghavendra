import csv

f = open("C:\\Users\\sainath\\Desktop\\empdata.csv","r")
rd =csv.reader(f) #return csv reader object

data = list(rd)
#print(data)
print("Reading the data from the CSV file")
for line in data:
    for word in line:
        print(word,"\t",end="")
    print()


