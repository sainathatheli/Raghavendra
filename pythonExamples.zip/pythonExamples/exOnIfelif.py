a=40
b=50
c=30

#if..elif..else statement
if a>b and a>c:
    print("a is greater than b,c")
elif b>c and b>a:
    print("b is greater than a,c")
else:
    print("c is greater than a,b")

#out of if..elif..else statment
print("out of if..elif..statement always executed")

