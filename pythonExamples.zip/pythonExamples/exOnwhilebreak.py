i=1

while i<=10:
    print(i)
    if(i == 5):
        break  #out of the loop when condition is true
    i+=1

print("out of while loop")