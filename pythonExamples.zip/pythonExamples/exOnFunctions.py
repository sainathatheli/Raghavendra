
#function declared and definition
def display():
    print("welcome to python functions ")

#function with parameter
def methodOne(s):
    print("Hello "+s)

#function with two parameters
def addition(x,y):
    print("sum of two numbers is :",x+y)

#function with return type
def methodTwo(a,b,c):
    return a+b+c

#calling a function
#functionName();
display()
methodOne("Ganesh")
addition(10,30)

#calling a function which return a value

res=methodTwo(10,30,40)
print("the sum of three numbers is : ",res)
print("the sum of three numbers is : ",methodTwo(10,20,20))
