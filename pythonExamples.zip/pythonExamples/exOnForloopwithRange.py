print("1 to 5 using for loop")
                     #end position not included
for x in range(1,6): # by default it will increment by 1
    print(x)  


print("1 to 10 using for loop increment by 2")

for x in range(1,11,2): #it will increment by 2
    print(x)

print("1 to 10 using for loop increment by 3")

for x in range(1,11,3): #it will increment by 3
    print(x)
else:
    print("once range is completed i.e condition become false then else executed")