def methodOne():      #function declared and definition is empty  then we need to use 
     pass              #pass keyword

#function argument taking the Collection as values
def myListDetails(l1):
     print("Element from Collection using function parameter ")
     for x in l1:
          print(x)


mylist=["Java","oracle","Dotnet","python","SpringBoot"]#list

s1={10,40,50,39,40} #set

t1=("apples",50,"orange",True,50,"ram") #tuple
#calling a function
myListDetails(mylist)
myListDetails(s1)
myListDetails(t1)
methodOne()






