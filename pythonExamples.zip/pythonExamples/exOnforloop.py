fruit="banana" #string
#print(fruit[0])
for x in fruit: 
    print(x)


#out of for loop
print("this statement out of for loop")

print("for loop with list")
fruits=["kiwi","mango","orange"];

print(fruits[0])

print("printing using for loop")

for x in fruits:
    print(x)