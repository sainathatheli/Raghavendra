i=1

#while loop

while i<=10:
    print(i)
    i=i+1

#out of while loop
print("out of the while loop")