import csv

with open("C:\\Users\\sainath\\Desktop\\emp.csv","w",newline="") as f:
   wt =csv.writer(f) #writer will return csv writer object
   wt.writerow(["ENO","ENAME","ESAL","EADDR"])
   wt.writerow(["1001","smith","4000","chennai"])
   
print("Data is written into a csv file")

