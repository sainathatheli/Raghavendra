
from exOnfirst import x as a,addition as sum

print("Member Aliasing")
print(a) #x
sum(10,30) #addition

#Note:
#once we defined as alias name, we should use alias name only and
#we should not use original name.