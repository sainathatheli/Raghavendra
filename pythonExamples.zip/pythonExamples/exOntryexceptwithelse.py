try:  #if enter wrong input then it will raise ValueError exception
    x = int(input("enter the value for numerator  "))
    y = int(input("enter the value for denominator"))

    z=x/y #when denominator  zero exception occured ZeroDivisionError ,we can caught this exception using except block

    print("Division of Two numbers is : ",z)

except ZeroDivisionError as msg:
    print("Division cannot be done by Zero")
    print(msg)
except ValueError as msg:
    print("input should be an int type")
    print(msg)
else:
    print("from else certain block will be executed when try executed with out error")