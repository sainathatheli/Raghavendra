#We can define customexception class inherits from the Exceptions class
class InvalidAgeException(Exception):
    pass

try:
    age=int(input("Enter the age : "))
    if age < 18 :
        raise InvalidAgeException
    else:
        print("Valid Age You can Cast your vote :")

except InvalidAgeException:
    print("Age should be greater than or equal to 18 to cast a vote")