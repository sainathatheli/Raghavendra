i=1
#while else statement
while i<=3:      
    print(i)
    i=i+1
else:
    print("while else block is executed if condition is false")

#out of while loop
print("out of while loop alway executed")