try:
    l1=[2,4,6,5,8]
    print(l1[5])
except IndexError as msg:
    print("index 5 element doesnot exist")
    print(msg)