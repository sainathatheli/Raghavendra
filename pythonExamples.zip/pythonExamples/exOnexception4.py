#handle the multiple exception in single except block
 
try:  #if enter wrong input then it will raise ValueError exception
    x = int(input("enter the value for numerator  "))
    y = int(input("enter the value for denominator"))

    z=x/y #when denominator  zero exception occured ZeroDivisionError ,we can caught this exception using except block

    print("Division of Two numbers is : ",z)

except (ZeroDivisionError,ValueError) as msg:
    print(msg)
