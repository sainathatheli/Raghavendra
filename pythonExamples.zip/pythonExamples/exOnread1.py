#open the file in read mode 'r'
# read total data from the file
print("read the total data ")
f = open("simple.txt",'r')
data = f.read() #total data will read from the file
print(data)
f.close()
print("--------------------------------")
#read only 10 character of data from simple.txt
print("read the n of character i.e 10 ")
f = open("simple.txt",'r')
dchar = f.read(12) # read only 12 characters.
print(dchar)
f.close()