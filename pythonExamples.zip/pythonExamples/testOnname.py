import myModule

myModule.f1()
