#mutli-level inheritance
class P1:

    def m1(self):
        print("we are in m1 method of P1 class")

class C1(P1):

    def m2(self):
        print("we are in m2 method of C1 class")

class SC(C1):

    def m3(self):
        print("we are in m3 method of SC of Sc class")

csobj = SC()  #creating object for subchild
csobj.m3() # calling subchild
csobj.m2() #calling from child
csobj.m3() #calling from Parent