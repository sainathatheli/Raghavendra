import exOnfirst

x=10
y=20

def f1():
    print("Hello")

def methodOne():
    print("we ar in methodOne")


#to print all members of current mode.
print("current module : ")
print(dir()) 

print("exonfirst module : ")
print(dir(exOnfirst)) # tolist all members of exOnfirst