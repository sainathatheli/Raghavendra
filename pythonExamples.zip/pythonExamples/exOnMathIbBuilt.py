from math import *
# import math
#print(dir(math)) #tolist all the members of math module
#print(math.sqrt(16))

print(sqrt(25))
print(ceil(9.6))
print(floor(9.3))
print(sin(90))