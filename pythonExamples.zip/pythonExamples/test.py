import exOnfirst  #importing the module exOnfirst.py

#acccessing a variable

print(exOnfirst.x) 


#calling a function from module
exOnfirst.addition(10,30)
exOnfirst.methodOne()