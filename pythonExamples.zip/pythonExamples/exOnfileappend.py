f=open("abcd.txt","a")
f.write("we are wirting this code on append mode \n")
f.write("python is a object orient programming langauge \n")
print("Data written to the file successfully")

f.close()