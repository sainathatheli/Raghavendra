x=-10

#check if x is greater than 0
if x > 0:
    print("x is positive integer")
    print("hello")
    
#out of if statment
print("this statement is always executed out of the if")