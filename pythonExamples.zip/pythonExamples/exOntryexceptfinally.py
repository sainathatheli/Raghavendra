try:
    numerator=10
    denominator=0
    result = numerator/denominator  #exception occured it will caught by except block
    print("the result is ",result)
except ZeroDivisionError as msg:
    print("Division cannot be done by zero")
    print("msg : ",msg)
finally:
    print("we are in finally block")