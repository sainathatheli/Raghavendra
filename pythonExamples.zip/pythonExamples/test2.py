#import only x variable and addition in our program

from exOnfirst import x,addition

print("using from..import")
print("x value is : ",x)
addition(40,60)
# methodOne() it thrown an error NameError: name 'methodOne' is not defined.
