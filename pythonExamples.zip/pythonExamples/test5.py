import test4 

print("using module name")

print(dir(test4)) # usingn module name