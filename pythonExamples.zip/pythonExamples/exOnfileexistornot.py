import os,sys

fname = input("Enter the filename : ")

if os.path.isfile(fname): # this line check file exist or not
    print("File exists: ",fname)
    #open the file in read mode and print it
    f=open(fname,'r')
else:
    print("File does not exist ",fname)
    sys.exit(0)

print("----------------------------------")
print("content from the file")
print("----------------------------------")
data =f.read()
print(data)

f.close()