#open the file in read mode 'r'
# read only one line or lines from the file
print("-----------------------------------------------")
print("read the line from file ")
print("-----------------------------------------------")
f = open("simple.txt",'r')
line1 = f.readline() #it will read only one line at time
print(line1,end="")
line2 = f.readline() #it will read only one line at time
print(line2,end="")
line3 = f.readline() #it will read only one line at time
print(line3,end="")
line4 = f.readline() #it will read only one line at time
print(line4,end="")
f.close()

print("-----------------------------------------------")
print("-----------------------------------------------")
print("read the all lines from file ")
print("-----------------------------------------------")

f = open("simple.txt",'r')
listlines =f.readlines()# to read all lines

for line in listlines:
    print(line,end="") 

f.close();