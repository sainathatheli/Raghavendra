x=input("Enter the value for x :") #by default it will read string 
y=input("Enter the value for y: ")

#convert the string to int
#casting()
a=int(x)
b=int(y)

z=a+b

print("calculation ",z)