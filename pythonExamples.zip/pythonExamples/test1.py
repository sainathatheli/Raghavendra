import exOnfirst as enf  

#here exOnfirst is original module name and enf is alias name.
#we can access members by using alias name enf
print("accessing the members using alias name")

print(enf.x)

enf.addition(30,20)
enf.methodOne()
 