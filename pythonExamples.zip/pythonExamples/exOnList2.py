l1=list(("apple","organge","mango","pineapple")) #initilaize the list using constructor

l2=["ramu",10,True,10.3,"ramu"]

print(l2)
#appending the element at end
l2.append("kiwi")
print("after append ",l2)

l2.insert(1,30) #element insert at index position 1
print("after insert at particular index ")
print(l2)

l2.remove(True) #pop(index position)
print("After remove: ")
print(l2)

print("conditional operations")
if "mangoo" in l1:
    print("yes mango exist in list l1")
else:
    print("not exist")

#copy(),sort(),clear(),reverse();

l1.reverse();
print("after reverse")
print(l1)

l1.sort()
print("after sort")
print(l1)

l3=l1.copy();
print("after copy in l3")
print(l3)

l3.clear();
print("after clear")
print(l3)

