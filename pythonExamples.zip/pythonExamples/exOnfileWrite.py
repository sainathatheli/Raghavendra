f=open("abcd.txt","w")
f.write("welcome to python \n")
f.write("we are wokring on files \n")
f.write("we are using visual studio \n")

l1=["banana \n","apple \n","mango \n"]
f.writelines(l1)
print("Data written to the file successfully")

f.close()