x=10   #.py file act as a module

def addition(a,b):
    print("the sum is : ",a+b)

def methodOne():
    print("we are in methodOne")