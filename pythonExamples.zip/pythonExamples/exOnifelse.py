a=5
b=10

#if-else statement
if a>b:
    print("a is greater than b")
else:
    print("b is greate than a ")

#out of if statement 
print("this statment always executed --out of if-else")