
def f1():
    if __name__ == '__main__':
        print("The code is executed as a individual program(direct)" ,__name__)
    else:
        print("the code executed as a module from some other program ",__name__)


f1()