class p1:
    def m1(self):
        print("we are in m1 of P1 class")

class p2:
    def m2(self):
        print("we are in m2 method of P2 class")

class C(p1,p2):
      
    def m3(self):
        print("we are in m3 method of Child class")


cobj = C()

cobj.m3() #calling from child
cobj.m2()#calling from parent2
cobj.m1() #calling from parent1


           