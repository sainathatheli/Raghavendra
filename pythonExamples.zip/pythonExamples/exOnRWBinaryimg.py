
f1 = open("C:\\Users\\sainath\\Desktop\\f1.jpg","rb")
f2 = open("newpic.jpg","wb")

#read the image
byt =f1.read()

#writing image into current directory
f2.write(byt) 

print("New image is available with name newpic.jpg in currrent directory")


